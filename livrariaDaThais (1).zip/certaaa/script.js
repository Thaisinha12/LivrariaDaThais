const booksCatalog = [
    { name: "A Hipótese do Amor", price: "R$ 30,00", image: "img/hipotese.jpeg" },
    { name: "Diário de uma Paixão", price: "R$ 40,00", image: "img/diarioDeUmaPaixao.jpeg" },
    { name: "O Capital", price: "R$ 50,00", image: "img/oCapital.png" },
    { name: "Noites Brancas", price: "R$ 60,00", image: "img/noitesBrancas.jpeg" },
    { name: "Verity", price: "R$ 35,00", image: "img/verity.jpeg" },
    { name: "Memórias do Subsolo", price: "R$ 45,00", image: "img/memoriasDoSubsolo.jpeg" },
    { name: "O Amor Não é Óbvio", price: "R$ 55,00", image: "img/oAmorNaoeObvio.jpeg" },
    { name: "O Príncipe Cruel", price: "R$ 60,00", image: "img/oPrincipeCruel.jpeg" },
    { name: "Estilhaça-me", price: "R$ 25,00", image: "img/estilhacame.jpeg" },
    { name: "Amor, Teoricamente", price: "R$ 20,00", image: "img/amorTeoricamente.jpeg" },
    { name: "A Rainha Vermelha", price: "R$ 30,00", image: "img/rainhaVermelha.jpeg" },
    { name: "1984", price: "R$ 35,00", image: "img/1984.jpeg" }
];

let cart = [];

function removeAccents(str) {
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function searchBook() {
    const searchTerm = removeAccents(document.getElementById("search-input").value.toLowerCase());

    if (searchTerm === "") {
        document.getElementById("search-result").innerHTML = '';
        return;
    }

    const result = booksCatalog.filter(book => 
        removeAccents(book.name.toLowerCase()).includes(searchTerm)
    );

    const searchResultContainer = document.getElementById("search-result");
    searchResultContainer.innerHTML = '';

    if (result.length > 0) {
        result.forEach(book => {
            const bookDiv = document.createElement("div");
            bookDiv.classList.add("search-result-item");
            bookDiv.innerHTML = `
                <div class="book">
                    <img src="${book.image}" alt="${book.name}">
                    <h3>${book.name}</h3>
                    <p>${book.price}</p>
                    <button onclick="addToCart('${book.name}', '${book.price}', '${book.image}')">Adicionar ao Carrinho</button>
                </div>
            `;
            searchResultContainer.appendChild(bookDiv);
        });
    } else {
        const noResult = document.createElement("p");
        noResult.textContent = "Nenhum livro encontrado.";
        searchResultContainer.appendChild(noResult);
    }
}

function addToCart(name, price, image) {
    const existingBook = cart.find(item => item.name === name);
    if (existingBook) {
        existingBook.quantity += 1;
    } else {
        cart.push({ name, price, image, quantity: 1 });
    }
    alert(`${name} foi adicionado ao carrinho!`);
    updateCart();
}

function updateCart() {
    const cartContainer = document.getElementById("cart");
    const cartItemsContainer = document.getElementById("cart-items");
    const cartTotalContainer = document.getElementById("cart-total");

    cartItemsContainer.innerHTML = '';

    if (cart.length === 0) {
        document.getElementById("checkout-btn").disabled = true;
        const noItemsMessage = document.createElement("p");
        noItemsMessage.textContent = "Seu carrinho está vazio.";
        cartItemsContainer.appendChild(noItemsMessage);
        cartTotalContainer.textContent = "Total: R$ 0,00";
    } else {
        let total = 0;
        cart.forEach(item => {
            const cartItem = document.createElement("div");
            cartItem.classList.add("cart-item");
            cartItem.innerHTML = `
                <img src="${item.image}" alt="${item.name}">
                <div>
                    <p>${item.name}</p>
                    <p>Quantidade: ${item.quantity}</p>
                    <p>${item.price}</p>
                </div>
                <button class="remove-btn" onclick="removeFromCart('${item.name}')">Remover</button>
            `;
            cartItemsContainer.appendChild(cartItem);

            // Convertendo o preço para número e somando
            total += parseFloat(item.price.replace('R$ ', '').replace(',', '.')) * item.quantity;
        });
        cartTotalContainer.textContent = `Total: R$ ${total.toFixed(2).replace('.', ',')}`;
        document.getElementById("checkout-btn").disabled = false;
    }
}

function removeFromCart(name) {
    cart = cart.filter(item => item.name !== name);
    updateCart();
}

function openCart() {
    const cartContainer = document.getElementById("cart");
    cartContainer.style.display = "block";
    updateCart();
}

function closeCart() {
    document.getElementById("cart").style.display = "none";
}

// Funções de pagamento via Pix
function showCheckoutForm() {
    if (cart.length === 0) {
        alert("O carrinho está vazio! Adicione itens antes de finalizar a compra.");
        return;
    }
    document.getElementById("checkout-form").style.display = "block";
}

function closeCheckoutForm() {
    document.getElementById("checkout-form").style.display = "none";
}

function completePurchase(event) {
    event.preventDefault();

    const name = document.getElementById("name").value;
    const cpf = document.getElementById("cpf").value;

    if (!name || !cpf || !isValidCPF(cpf)) {
        alert("Preencha todos os campos corretamente, e verifique se o CPF é válido.");
        return;
    }

    generatePixQRCode(name);
}

function isValidCPF(cpf) {
    cpf = cpf.replace(/[^\d]+/g, ''); // Remove caracteres não numéricos

    if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) return false;

    let sum = 0;
    let remainder;

    for (let i = 1; i <= 9; i++) {
        sum += parseInt(cpf[i - 1]) * (11 - i);
    }
    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(cpf[9])) return false;

    sum = 0;
    for (let i = 1; i <= 10; i++) {
        sum += parseInt(cpf[i - 1]) * (12 - i);
    }
    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(cpf[10])) return false;

    return true;
}

function generatePixQRCode(name) {
    const pixCode = `00020126360014BR.GOV.BCB.PIX0114+559999999999520400005303986540510.005802BR5920${name}6009SaoPaulo62100506ABC1236304ABCD`;
    const qrCodeURL = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(pixCode)}`;

    document.getElementById("checkout-form").style.display = "none";
    document.getElementById("pix-qrcode").style.display = "block";
    document.getElementById("qrcode-img").src = qrCodeURL;
}

function finishPixPayment() {
    alert("Pagamento confirmado! Obrigado pela compra.");
    cart = [];
    updateCart();
    closeCart();
    document.getElementById("pix-qrcode").style.display = "none";
}
